@echo off
title Mini Paint Station - Kids Art & Paint Studio
echo ================================================================
echo           Mini Paint Station (Windows Desktop App)
echo ================================================================
echo Starting Mini Paint Station in standalone app window...
start msedge --app="https://minipaintstation.shop" 2>nul || start chrome --app="https://minipaintstation.shop" 2>nul || start "" "https://minipaintstation.shop"
exit
