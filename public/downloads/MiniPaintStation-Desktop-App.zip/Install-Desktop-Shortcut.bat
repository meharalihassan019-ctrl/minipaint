@echo off
title Install Mini Paint Station Desktop Shortcut
echo Creating Mini Paint Station shortcut on your Desktop...
set "DESKTOP=%USERPROFILE%\Desktop"
set "SHORTCUT=%DESKTOP%\Mini Paint Station.url"
(
echo [InternetShortcut]
echo URL=https://minipaintstation.shop
echo IconIndex=0
echo IconFile=https://minipaintstation.shop/favicon.ico
) > "%SHORTCUT%"
echo.
echo ================================================================
echo [SUCCESS] Mini Paint Station shortcut added to your Desktop!
echo اب آپ کے ڈیسک ٹاپ پر Mini Paint Station کا شارٹ کٹ بن گیا ہے۔
echo ================================================================
echo.
pause
